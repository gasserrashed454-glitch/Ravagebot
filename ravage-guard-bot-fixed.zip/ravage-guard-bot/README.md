# Ravage Guard Bot

Discord moderation bot for Ravage SMP.

## Setup

1. Install dependencies: `npm install`
2. Edit `.env` and fill in your values:
   - `DISCORD_BOT_TOKEN` — your bot token from the Discord Developer Portal
   - `CLIENT_ID` — your bot's application ID
   - `GUILD_ID` — *(optional)* your server's ID for instant command registration. Remove this line to deploy globally (takes up to 1 hour to appear everywhere).
3. Deploy slash commands: `node src/deploy-commands.js`
4. Start the bot: `npm start`

## Features

- Moderation: ban, kick, mute, warn, clear
- Anti-Swear filter
- Anti-Nuke protection (bans, kicks, channel deletes, role deletes, webhook spam)
- Dead Chat revival
- Ticket system with categories, transcript logging on close
- Staff application system with accept/decline (with reason)

## Ticket System

- `/setticket` or `/tickets setup` to configure
- When a ticket is closed, the full message transcript is posted to the log channel
- Ticket log shows: channel name, type, who opened it, who closed it, message count, and the full conversation

## Staff Applications

- `/setapply` to configure the application panel
- When staff clicks Accept or Decline, a modal pops up asking for a reason
- The reason is included in the application log and sent to the applicant via DM
