import { handleGuildMemberRemove } from '../systems/antinuke.js';

export default {
  name: 'guildMemberRemove',
  async execute(member, client) {
    await handleGuildMemberRemove(member, client);
  },
};
