import { EmbedBuilder } from 'discord.js';
import { getConfig } from '../config.js';

export default {
  name: 'messageUpdate',
  async execute(oldMessage, newMessage, client) {
    if (!newMessage.guild) return;
    if (newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return; // Content unchanged (embed update, etc.)

    const config = getConfig(newMessage.guild.id);
    if (!config.logger.channel) return;

    const logCh = newMessage.guild.channels.cache.get(config.logger.channel);
    if (!logCh) return;

    // Ghost ping via edit — had mentions before, no longer does
    const hadMentions =
      !oldMessage.partial &&
      oldMessage.mentions &&
      (oldMessage.mentions.users.size > 0 || oldMessage.mentions.roles.size > 0) &&
      !oldMessage.mentions.everyone;

    const nowHasMentions =
      newMessage.mentions &&
      (newMessage.mentions.users.size > 0 || newMessage.mentions.roles.size > 0);

    if (config.logger.logGhostPings && hadMentions && !nowHasMentions) {
      const mentionedUsers = oldMessage.mentions.users.map(u => `<@${u.id}>`).join(', ');
      const mentionedRoles = oldMessage.mentions.roles.map(r => `<@&${r.id}>`).join(', ');
      const targets = [mentionedUsers, mentionedRoles].filter(Boolean).join(', ');

      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('Ghost Ping — Message Edited')
        .addFields(
          { name: 'Author', value: `<@${newMessage.author.id}> (${newMessage.author.username})`, inline: true },
          { name: 'Channel', value: `<#${newMessage.channel.id}>`, inline: true },
          { name: 'Pinged', value: targets, inline: false },
          { name: 'Before', value: oldMessage.content ? oldMessage.content.slice(0, 512) : '*Unavailable*', inline: false },
          { name: 'After', value: newMessage.content ? newMessage.content.slice(0, 512) : '*Empty*', inline: false },
        )
        .addFields({ name: 'Jump to Message', value: `[Click here](${newMessage.url})`, inline: false })
        .setFooter({ text: 'Ravage Guard — Ghost Ping Log' })
        .setTimestamp();

      await logCh.send({ embeds: [embed] }).catch(() => {});
      return;
    }

    // Normal edit log
    if (!config.logger.logEdited) return;

    const before = oldMessage.partial ? '*Not available (message was sent before bot started)*' : (oldMessage.content?.slice(0, 512) || '*Empty*');
    const after = newMessage.content?.slice(0, 512) || '*Empty*';

    if (before === after) return;

    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle('Message Edited')
      .addFields(
        { name: 'Author', value: `<@${newMessage.author.id}> (${newMessage.author.username})`, inline: true },
        { name: 'Channel', value: `<#${newMessage.channel.id}>`, inline: true },
        { name: 'Before', value: before, inline: false },
        { name: 'After', value: after, inline: false },
        { name: 'Jump to Message', value: `[Click here](${newMessage.url})`, inline: false },
      )
      .setFooter({ text: `Message ID: ${newMessage.id} | Ravage Guard — Message Log` })
      .setTimestamp();

    await logCh.send({ embeds: [embed] }).catch(() => {});
  },
};
