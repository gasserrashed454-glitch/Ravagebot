import { handleWebhookCreate } from '../systems/antinuke.js';

export default {
  name: 'webhooksUpdate',
  async execute(channel, client) {
    await handleWebhookCreate(channel, client);
  },
};
