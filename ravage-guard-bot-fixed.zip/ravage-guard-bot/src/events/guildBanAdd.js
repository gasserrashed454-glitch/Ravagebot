import { handleGuildBanAdd } from '../systems/antinuke.js';

export default {
  name: 'guildBanAdd',
  async execute(ban, client) {
    await handleGuildBanAdd(ban, client);
  },
};
