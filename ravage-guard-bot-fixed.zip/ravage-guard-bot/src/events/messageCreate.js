import { handleAntiSwear } from '../systems/antiswear.js';
import { trackMessage } from '../systems/deadchat.js';
import { handleApplyDMResponse, pendingApplications } from '../systems/apply.js';

const IP_KEYWORDS = ['ip', 'server ip', 'what is the ip', 'whats the ip', 'server address'];
const SERVER_IP = 'play.ravagesmp.live';

export default {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot) return;

    // Handle DM messages for pending applications
    if (!message.guild) {
      if (pendingApplications.has(message.author.id)) {
        await handleApplyDMResponse(message, client);
      }
      return;
    }

    // Server message handling
    trackMessage(message);
    await handleAntiSwear(message, client);

    const content = message.content.toLowerCase().trim();
    const isIpQuery = IP_KEYWORDS.some(kw => content === kw || content.includes(kw + '?') || content.includes(kw + '!'));

    if (isIpQuery) {
      await message.reply({
        embeds: [{
          color: 0x1ABC9C,
          title: 'Ravage SMP Server IP',
          description: `**\`${SERVER_IP}\`**`,
          footer: { text: 'Ravage Guard — Server Info' },
          timestamp: new Date().toISOString(),
        }],
      }).catch(() => {});
    }
  },
};
