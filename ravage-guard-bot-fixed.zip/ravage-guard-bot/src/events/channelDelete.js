import { handleChannelDelete } from '../systems/antinuke.js';

export default {
  name: 'channelDelete',
  async execute(channel, client) {
    await handleChannelDelete(channel, client);
  },
};
