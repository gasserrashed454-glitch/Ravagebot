export default {
  name: 'guildCreate',
  async execute(guild, client) {
    console.log(`➕ Joined guild: ${guild.name} (${guild.id}) — ${guild.memberCount} members`);

    const channel = guild.systemChannel || guild.channels.cache
      .filter(c => c.type === 0 && c.permissionsFor(guild.members.me).has('SendMessages'))
      .first();

    if (channel) {
      await channel.send({
        embeds: [{
          color: 0x1ABC9C,
          title: '🛡️ Ravage Guard has arrived!',
          description: 'Thanks for adding **Ravage Guard** to your server!\n\nI\'m your all-in-one moderation assistant. Here\'s how to get started:',
          fields: [
            { name: '⚔️ Moderation', value: '`/ban`, `/kick`, `/mute`, `/warn`, `/clear`', inline: false },
            { name: '🧹 Anti-Swear', value: 'Use `/antiswear setup` to configure the filter', inline: false },
            { name: '🛡️ Anti-Nuke', value: 'Use `/antinuke setup` to protect your server', inline: false },
            { name: '💀 Dead Chat', value: 'Use `/deadchat setup` to revive inactive channels', inline: false },
            { name: '🎫 Tickets', value: 'Use `/tickets setup` to create a support system', inline: false },
            { name: '🌐 Server IP', value: 'Anyone who types "ip" gets `play.ravagesmp.live` automatically!', inline: false },
          ],
          footer: { text: 'Ravage Guard • Made for Ravage SMP' },
          timestamp: new Date().toISOString(),
        }],
      }).catch(() => {});
    }
  },
};
