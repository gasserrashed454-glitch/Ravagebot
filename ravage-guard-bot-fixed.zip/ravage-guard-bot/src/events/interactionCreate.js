import { PermissionsBitField } from 'discord.js';
import { openTicket, closeTicket, claimTicket, openCategorizedTicket } from '../systems/tickets.js';
import {
  openApplyDM,
  openAcceptReasonModal,
  openDeclineReasonModal,
  handleApplyAcceptWithReason,
  handleApplyDeclineWithReason,
} from '../systems/apply.js';
import { errorEmbed } from '../utils/embeds.js';

const CATEGORIZED_TICKET_IDS = [
  'ticket_open_report',
  'ticket_open_appeal',
  'ticket_open_roleapply',
  'ticket_open_partner',
  'ticket_open_support',
];

export default {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      // Runtime permission check — secondary guard beyond Discord's UI enforcement
      const requiredPerms = command.data.default_member_permissions;
      if (requiredPerms !== null && requiredPerms !== undefined) {
        const required = new PermissionsBitField(BigInt(requiredPerms));
        if (!interaction.memberPermissions?.has(required)) {
          return interaction.reply({
            embeds: [errorEmbed('No Permission', 'You do not have permission to use this command.')],
            ephemeral: true,
          });
        }
      }

      try {
        await command.execute(interaction, client);
      } catch (err) {
        console.error(`Error executing /${interaction.commandName}:`, err);
        const embed = errorEmbed('Command Error', 'An error occurred while running this command.');
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [embed], ephemeral: true }).catch(() => {});
        } else {
          await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => {});
        }
      }
    }

    if (interaction.isButton()) {
      if (interaction.customId === 'ticket_open') {
        await openTicket(interaction);
      } else if (CATEGORIZED_TICKET_IDS.includes(interaction.customId)) {
        await openCategorizedTicket(interaction, interaction.customId);
      } else if (interaction.customId === 'ticket_close') {
        await closeTicket(interaction);
      } else if (interaction.customId === 'ticket_claim') {
        await claimTicket(interaction);
      } else if (interaction.customId === 'apply_open') {
        await openApplyDM(interaction);
      } else if (interaction.customId.startsWith('apply_accept_')) {
        await openAcceptReasonModal(interaction);
      } else if (interaction.customId.startsWith('apply_decline_')) {
        await openDeclineReasonModal(interaction);
      }
    }

    if (interaction.isModalSubmit()) {
      if (interaction.customId.startsWith('apply_accept_reason_')) {
        await handleApplyAcceptWithReason(interaction);
      } else if (interaction.customId.startsWith('apply_decline_reason_')) {
        await handleApplyDeclineWithReason(interaction);
      }
    }
  },
};
