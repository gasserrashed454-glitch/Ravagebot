import { ActivityType } from 'discord.js';
import { initDeadChatTimers } from '../systems/deadchat.js';

export default {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`✅ Ravage Guard is online as ${client.user.username}`);
    console.log(`📡 Serving ${client.guilds.cache.size} guild(s)`);

    client.user.setPresence({
      activities: [{ name: 'over your server 🛡️', type: ActivityType.Watching }],
      status: 'online',
    });

    initDeadChatTimers(client);
  },
};
