import { EmbedBuilder, AuditLogEvent } from 'discord.js';
import { getConfig } from '../config.js';

export default {
  name: 'messageDelete',
  async execute(message, client) {
    if (!message.guild) return;
    if (message.author?.bot) return;

    const config = getConfig(message.guild.id);
    if (!config.logger.channel) return;

    const logCh = message.guild.channels.cache.get(config.logger.channel);
    if (!logCh) return;

    const isGhostPing =
      config.logger.logGhostPings &&
      message.mentions &&
      (message.mentions.users.size > 0 || message.mentions.roles.size > 0) &&
      !message.mentions.everyone;

    // Ghost ping — handle first and separate from normal deleted log
    if (isGhostPing) {
      const mentionedUsers = message.mentions.users.map(u => `<@${u.id}>`).join(', ');
      const mentionedRoles = message.mentions.roles.map(r => `<@&${r.id}>`).join(', ');
      const targets = [mentionedUsers, mentionedRoles].filter(Boolean).join(', ');

      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('Ghost Ping Detected')
        .addFields(
          { name: 'Author', value: message.author ? `<@${message.author.id}> (${message.author.username})` : 'Unknown', inline: true },
          { name: 'Channel', value: `<#${message.channel.id}>`, inline: true },
          { name: 'Pinged', value: targets, inline: false },
          { name: 'Message', value: message.content ? message.content.slice(0, 1024) : '*No text content*', inline: false },
        )
        .setFooter({ text: 'Ravage Guard — Ghost Ping Log' })
        .setTimestamp();

      await logCh.send({ embeds: [embed] }).catch(() => {});
      return;
    }

    // Normal deleted message log
    if (!config.logger.logDeleted) return;
    if (message.partial) return; // Message not in cache, can't log content

    const embed = new EmbedBuilder()
      .setColor(0xED4245)
      .setTitle('Message Deleted')
      .addFields(
        { name: 'Author', value: message.author ? `<@${message.author.id}> (${message.author.username})` : 'Unknown', inline: true },
        { name: 'Channel', value: `<#${message.channel.id}>`, inline: true },
      );

    if (message.content) {
      embed.addFields({ name: 'Content', value: message.content.slice(0, 1024), inline: false });
    } else if (message.attachments.size > 0) {
      const files = message.attachments.map(a => a.url).join('\n');
      embed.addFields({ name: 'Attachment(s)', value: files.slice(0, 1024), inline: false });
    } else {
      embed.addFields({ name: 'Content', value: '*No text content (embed or attachment)*', inline: false });
    }

    if (message.attachments.size > 0 && message.content) {
      const files = message.attachments.map(a => a.name).join(', ');
      embed.addFields({ name: 'Attachments', value: files.slice(0, 512), inline: false });
    }

    embed
      .setFooter({ text: `Message ID: ${message.id} | Ravage Guard — Message Log` })
      .setTimestamp();

    await logCh.send({ embeds: [embed] }).catch(() => {});
  },
};
