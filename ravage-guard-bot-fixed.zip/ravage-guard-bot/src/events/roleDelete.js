import { handleRoleDelete } from '../systems/antinuke.js';

export default {
  name: 'roleDelete',
  async execute(role, client) {
    await handleRoleDelete(role, client);
  },
};
