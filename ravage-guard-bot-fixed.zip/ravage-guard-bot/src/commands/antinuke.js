import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';
import { getConfig, saveConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('antinuke')
    .setDescription('Manage the anti-nuke protection system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub => sub.setName('enable').setDescription('Enable anti-nuke protection'))
    .addSubcommand(sub => sub.setName('disable').setDescription('Disable anti-nuke protection'))
    .addSubcommand(sub =>
      sub.setName('setlog')
        .setDescription('Set the anti-nuke log channel')
        .addChannelOption(o => o.setName('channel').setDescription('Log channel').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('whitelist')
        .setDescription('Whitelist a user from anti-nuke')
        .addUserOption(o => o.setName('user').setDescription('User to whitelist').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('unwhitelist')
        .setDescription('Remove a user from the whitelist')
        .addUserOption(o => o.setName('user').setDescription('User to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('action')
        .setDescription('Set punishment for nuke attempts')
        .addStringOption(o =>
          o.setName('type').setDescription('Punishment type').setRequired(true)
            .addChoices(
              { name: '🔨 Ban', value: 'ban' },
              { name: '👢 Kick', value: 'kick' },
              { name: '🎭 Remove Roles', value: 'derank' },
            )
        )
    )
    .addSubcommand(sub => sub.setName('status').setDescription('View anti-nuke configuration')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const config = getConfig(interaction.guild.id);

    if (sub === 'enable') {
      config.antinuke.enabled = true;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({
        embeds: [successEmbed('Anti-Nuke Enabled', '🛡️ Your server is now protected against mass bans, kicks, channel deletions, and more.')],
      });
    }

    if (sub === 'disable') {
      config.antinuke.enabled = false;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Anti-Nuke Disabled', 'Anti-nuke protection has been disabled.')] });
    }

    if (sub === 'setlog') {
      const channel = interaction.options.getChannel('channel');
      config.antinuke.logChannel = channel.id;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Log Channel Set', `Anti-nuke events will be logged in ${channel}.`)] });
    }

    if (sub === 'whitelist') {
      const user = interaction.options.getUser('user');
      if (!config.antinuke.whitelistedUsers.includes(user.id)) {
        config.antinuke.whitelistedUsers.push(user.id);
        saveConfig(interaction.guild.id, config);
      }
      return interaction.reply({ embeds: [successEmbed('User Whitelisted', `**${user.username}** is now exempt from anti-nuke detection.`)] });
    }

    if (sub === 'unwhitelist') {
      const user = interaction.options.getUser('user');
      config.antinuke.whitelistedUsers = config.antinuke.whitelistedUsers.filter(id => id !== user.id);
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('User Removed', `**${user.username}** has been removed from the whitelist.`)] });
    }

    if (sub === 'action') {
      const type = interaction.options.getString('type');
      config.antinuke.punishAction = type;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Action Updated', `Nuke attempts will now result in: **${type.toUpperCase()}**`)] });
    }

    if (sub === 'status') {
      const wl = config.antinuke.whitelistedUsers.map(id => `<@${id}>`).join(', ') || 'None';
      return interaction.reply({
        embeds: [{
          color: 0x1ABC9C,
          title: '🛡️ Anti-Nuke Configuration',
          fields: [
            { name: 'Status', value: config.antinuke.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
            { name: 'Punishment', value: config.antinuke.punishAction.toUpperCase(), inline: true },
            { name: 'Log Channel', value: config.antinuke.logChannel ? `<#${config.antinuke.logChannel}>` : 'Not set', inline: true },
            { name: 'Thresholds', value: `Bans: ${config.antinuke.thresholds.bans}\nKicks: ${config.antinuke.thresholds.kicks}\nChannel Deletes: ${config.antinuke.thresholds.channelDeletes}\nRole Deletes: ${config.antinuke.thresholds.roleDeletes}\nWebhook Creates: ${config.antinuke.thresholds.webhookCreates}`, inline: false },
            { name: 'Whitelisted Users', value: wl, inline: false },
          ],
          footer: { text: 'Ravage Guard • Anti-Nuke' },
          timestamp: new Date().toISOString(),
        }],
        ephemeral: true,
      });
    }
  },
};
