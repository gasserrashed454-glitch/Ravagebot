import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';
import { getConfig, saveConfig } from '../config.js';
import { sendApplyPanel } from '../systems/apply.js';

export default {
  data: new SlashCommandBuilder()
    .setName('setapply')
    .setDescription('Send the staff application panel to a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption(o => o.setName('channel').setDescription('Channel to post the apply panel in').setRequired(true))
    .addChannelOption(o => o.setName('logchannel').setDescription('Channel where submitted applications are sent').setRequired(false))
    .addRoleOption(o => o.setName('acceptrole').setDescription('Role automatically given to accepted applicants').setRequired(false))
    .addStringOption(o => o.setName('emoji').setDescription('Emoji for the Apply Now button (e.g. 📝 or <:custom:123456>)').setRequired(false)),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const logChannel = interaction.options.getChannel('logchannel');
    const acceptRole = interaction.options.getRole('acceptrole');
    const emoji = interaction.options.getString('emoji');

    const config = getConfig(interaction.guild.id);
    if (!config.apply) config.apply = {};
    config.apply.panelChannel = channel.id;
    if (logChannel) config.apply.logChannel = logChannel.id;
    if (acceptRole) config.apply.acceptRole = acceptRole.id;
    if (emoji !== null) config.apply.buttonEmoji = emoji.trim() || null;
    saveConfig(interaction.guild.id, config);

    try {
      await sendApplyPanel(channel, config.apply.buttonEmoji);

      const lines = [`Panel sent to ${channel}.`];
      if (logChannel) lines.push(`Applications go to ${logChannel}.`);
      if (acceptRole) lines.push(`Accepted applicants will receive the ${acceptRole} role.`);
      if (emoji) lines.push(`Button emoji set to ${emoji}`);
      if (!logChannel) lines.push('\n**Tip:** Add a `logchannel` so applications have somewhere to go.');

      return interaction.reply({
        embeds: [successEmbed('Apply Panel Sent', lines.join('\n'))],
        ephemeral: true,
      });
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed('Failed', err.message)], ephemeral: true });
    }
  },
};
