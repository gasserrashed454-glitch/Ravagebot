import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';
import { getConfig, saveConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('modlog')
    .setDescription('Set the moderation log channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('set')
        .setDescription('Set the modlog channel')
        .addChannelOption(o => o.setName('channel').setDescription('Log channel').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('disable').setDescription('Disable the modlog')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const config = getConfig(interaction.guild.id);

    if (sub === 'set') {
      const channel = interaction.options.getChannel('channel');
      config.modlog.channel = channel.id;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Modlog Set', `All moderation actions will be logged in ${channel}.`)] });
    }

    if (sub === 'disable') {
      config.modlog.channel = null;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Modlog Disabled', 'Moderation logging has been disabled.')] });
    }
  },
};
