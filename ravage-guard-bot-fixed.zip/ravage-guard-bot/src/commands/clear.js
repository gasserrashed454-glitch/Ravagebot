import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';

export default {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Delete messages from a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(o => o.setName('amount').setDescription('Number of messages to delete (1-100)').setMinValue(1).setMaxValue(100).setRequired(true))
    .addUserOption(o => o.setName('user').setDescription('Only delete messages from this user').setRequired(false)),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const targetUser = interaction.options.getUser('user');

    await interaction.deferReply({ ephemeral: true });

    try {
      let messages = await interaction.channel.messages.fetch({ limit: 100 });

      if (targetUser) {
        messages = messages.filter(m => m.author.id === targetUser.id);
      }

      messages = [...messages.values()].slice(0, amount);
      const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
      const deletable = messages.filter(m => m.createdTimestamp > twoWeeksAgo);

      if (deletable.length === 0) {
        return interaction.editReply({ embeds: [errorEmbed('Nothing to Delete', 'No messages found that can be deleted (messages must be under 14 days old).')] });
      }

      const deleted = await interaction.channel.bulkDelete(deletable, true);

      await interaction.editReply({
        embeds: [successEmbed('Messages Cleared', `Successfully deleted **${deleted.size}** message(s)${targetUser ? ` from **${targetUser.username}**` : ''}.`)],
      });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Clear Failed', err.message)] });
    }
  },
};
