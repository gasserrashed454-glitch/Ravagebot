import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed, modLogEmbed } from '../utils/embeds.js';
import { getConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Remove a timeout from a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('The user to unmute').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')], ephemeral: true });
    if (!target.isCommunicationDisabled()) return interaction.reply({ embeds: [errorEmbed('Not Muted', 'That user is not muted.')], ephemeral: true });

    try {
      await target.timeout(null, reason);
      await interaction.reply({ embeds: [successEmbed('User Unmuted', `**${target.user.username}** has been unmuted.`)] });

      const config = getConfig(interaction.guild.id);
      if (config.modlog.channel) {
        const logCh = interaction.guild.channels.cache.get(config.modlog.channel);
        if (logCh) {
          logCh.send({ embeds: [modLogEmbed({ action: 'UNMUTE', user: target.user, moderator: interaction.user, reason })] }).catch(() => {});
        }
      }
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Unmute Failed', err.message)], ephemeral: true });
    }
  },
};
