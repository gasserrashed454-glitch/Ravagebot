import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';

export default {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock or unlock a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand(sub =>
      sub.setName('channel')
        .setDescription('Lock this channel (prevent members from sending messages)')
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('unlock')
        .setDescription('Unlock this channel')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const channel = interaction.channel;
    const everyoneRole = interaction.guild.roles.everyone;

    if (sub === 'channel') {
      const reason = interaction.options.getString('reason') || 'No reason provided';
      try {
        await channel.permissionOverwrites.edit(everyoneRole, { SendMessages: false }, { reason });
        await interaction.reply({
          embeds: [{
            color: 0xE74C3C,
            title: '🔒 Channel Locked',
            description: `This channel has been locked.\n**Reason:** ${reason}`,
            footer: { text: `Locked by ${interaction.user.username} • Ravage Guard` },
            timestamp: new Date().toISOString(),
          }],
        });
      } catch (err) {
        await interaction.reply({ embeds: [errorEmbed('Failed', err.message)], ephemeral: true });
      }
    }

    if (sub === 'unlock') {
      try {
        await channel.permissionOverwrites.edit(everyoneRole, { SendMessages: null });
        await interaction.reply({
          embeds: [{
            color: 0x2ECC71,
            title: '🔓 Channel Unlocked',
            description: 'This channel has been unlocked. Members can send messages again.',
            footer: { text: `Unlocked by ${interaction.user.username} • Ravage Guard` },
            timestamp: new Date().toISOString(),
          }],
        });
      } catch (err) {
        await interaction.reply({ embeds: [errorEmbed('Failed', err.message)], ephemeral: true });
      }
    }
  },
};
