import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';

export default {
  data: new SlashCommandBuilder()
    .setName('hidecmd')
    .setDescription('Hide or show a slash command from regular members')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('hide')
        .setDescription('Hide a command so only admins can see and use it')
        .addStringOption(o =>
          o.setName('command').setDescription('Name of the command to hide (e.g. ban, setlogger)').setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('show')
        .setDescription('Restore a command so all members can see and use it again')
        .addStringOption(o =>
          o.setName('command').setDescription('Name of the command to restore').setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all currently hidden commands')
    ),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      await interaction.deferReply({ ephemeral: true });

      const guildCmds = await interaction.guild.commands.fetch().catch(() => null);
      const globalCmds = await client.application.commands.fetch().catch(() => null);

      const hidden = [];

      if (guildCmds) {
        for (const cmd of guildCmds.values()) {
          if (cmd.defaultMemberPermissions !== null && cmd.defaultMemberPermissions?.bitfield === 0n) {
            hidden.push(`\`/${cmd.name}\` (server-only)`);
          }
        }
      }
      if (globalCmds) {
        for (const cmd of globalCmds.values()) {
          if (cmd.defaultMemberPermissions !== null && cmd.defaultMemberPermissions?.bitfield === 0n) {
            hidden.push(`\`/${cmd.name}\` (global)`);
          }
        }
      }

      if (hidden.length === 0) {
        return interaction.editReply({ embeds: [successEmbed('Hidden Commands', 'No commands are currently hidden.')] });
      }

      return interaction.editReply({
        embeds: [successEmbed('Hidden Commands', hidden.join('\n'))],
      });
    }

    const commandName = interaction.options.getString('command').toLowerCase().replace(/^\//, '');
    const hiding = sub === 'hide';

    await interaction.deferReply({ ephemeral: true });

    // Try guild commands first, then global
    let found = false;

    const guildCmds = await interaction.guild.commands.fetch().catch(() => null);
    if (guildCmds) {
      const cmd = guildCmds.find(c => c.name === commandName);
      if (cmd) {
        await cmd.edit({ defaultMemberPermissions: hiding ? '0' : null });
        found = true;
      }
    }

    if (!found) {
      const globalCmds = await client.application.commands.fetch().catch(() => null);
      if (globalCmds) {
        const cmd = globalCmds.find(c => c.name === commandName);
        if (cmd) {
          await client.application.commands.edit(cmd.id, {
            defaultMemberPermissions: hiding ? '0' : null,
          });
          found = true;
        }
      }
    }

    if (!found) {
      return interaction.editReply({
        embeds: [errorEmbed('Command Not Found', `No command named \`/${commandName}\` was found.\n\nMake sure you've run the deploy script first and the command name is spelled correctly.`)],
      });
    }

    if (hiding) {
      return interaction.editReply({
        embeds: [successEmbed('Command Hidden', `\`/${commandName}\` is now hidden from regular members.\nOnly server admins can see and use it.\n\nTo restore it, use \`/hidecmd show ${commandName}\`.`)],
      });
    } else {
      return interaction.editReply({
        embeds: [successEmbed('Command Restored', `\`/${commandName}\` is now visible to all members again.`)],
      });
    }
  },
};
