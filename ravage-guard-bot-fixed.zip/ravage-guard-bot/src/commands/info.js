import { SlashCommandBuilder, PermissionFlagsBits, version as djsVersion } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('info')
    .setDescription('View bot information and stats — admin only')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const client = interaction.client;
    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const uptimeStr = `${days}d ${hours}h ${minutes}m`;

    const totalMembers = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);

    await interaction.reply({
      embeds: [{
        color: 0x1ABC9C,
        title: '🛡️ Ravage Guard',
        description: 'Professional Discord moderation bot built for Ravage SMP.',
        thumbnail: { url: client.user.displayAvatarURL() },
        fields: [
          { name: '📡 Servers', value: `${client.guilds.cache.size}`, inline: true },
          { name: '👥 Total Members', value: `${totalMembers.toLocaleString()}`, inline: true },
          { name: '⏱️ Uptime', value: uptimeStr, inline: true },
          { name: '🔧 Discord.js', value: `v${djsVersion}`, inline: true },
          { name: '📦 Node.js', value: process.version, inline: true },
          { name: '💾 Memory', value: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`, inline: true },
          { name: '🌐 Server IP', value: '`play.ravagesmp.live`', inline: false },
          { name: '⚡ Features', value: '✅ Anti-Swear\n✅ Anti-Nuke\n✅ Dead Chat Revival\n✅ Ticket System\n✅ Full Moderation\n✅ Mod Logging', inline: false },
        ],
        footer: { text: 'Ravage Guard • Made for Ravage SMP' },
        timestamp: new Date().toISOString(),
      }],
    });
  },
};
