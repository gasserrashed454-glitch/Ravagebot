import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';
import { sendAdvancedTicketPanel } from '../systems/tickets.js';
import { getConfig, saveConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('setticket')
    .setDescription('Quickly send the ticket panel with all categories to a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption(o => o.setName('channel').setDescription('Channel to send the ticket panel in').setRequired(true))
    .addRoleOption(o => o.setName('supportrole').setDescription('Role that can see and manage tickets').setRequired(false))
    .addChannelOption(o => o.setName('category').setDescription('Category to create ticket channels under').setRequired(false))
    .addChannelOption(o => o.setName('logchannel').setDescription('Channel to log ticket events').setRequired(false))
    .addStringOption(o => o.setName('emoji_report').setDescription('Emoji for the Report Member button (e.g. 🚨)').setRequired(false))
    .addStringOption(o => o.setName('emoji_appeal').setDescription('Emoji for the Punish Appeal button (e.g. ⚖️)').setRequired(false))
    .addStringOption(o => o.setName('emoji_roleapply').setDescription('Emoji for the Role Apply button (e.g. 📋)').setRequired(false))
    .addStringOption(o => o.setName('emoji_partner').setDescription('Emoji for the Partner button (e.g. 🤝)').setRequired(false))
    .addStringOption(o => o.setName('emoji_support').setDescription('Emoji for the Support button (e.g. 🎫)').setRequired(false)),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const supportRole = interaction.options.getRole('supportrole');
    const category = interaction.options.getChannel('category');
    const logChannel = interaction.options.getChannel('logchannel');
    const emojiReport    = interaction.options.getString('emoji_report');
    const emojiAppeal    = interaction.options.getString('emoji_appeal');
    const emojiRoleapply = interaction.options.getString('emoji_roleapply');
    const emojiPartner   = interaction.options.getString('emoji_partner');
    const emojiSupport   = interaction.options.getString('emoji_support');

    const config = getConfig(interaction.guild.id);
    config.tickets.enabled = true;
    if (supportRole) config.tickets.supportRole = supportRole.id;
    if (category) config.tickets.category = category.id;
    if (logChannel) config.tickets.logChannel = logChannel.id;

    if (!config.ticketEmojis) config.ticketEmojis = {};
    if (emojiReport    !== null) config.ticketEmojis.report    = emojiReport?.trim()    || null;
    if (emojiAppeal    !== null) config.ticketEmojis.appeal    = emojiAppeal?.trim()    || null;
    if (emojiRoleapply !== null) config.ticketEmojis.roleapply = emojiRoleapply?.trim() || null;
    if (emojiPartner   !== null) config.ticketEmojis.partner   = emojiPartner?.trim()   || null;
    if (emojiSupport   !== null) config.ticketEmojis.support   = emojiSupport?.trim()   || null;

    saveConfig(interaction.guild.id, config);

    try {
      await sendAdvancedTicketPanel(channel, interaction.guild);

      const emojiSet = [emojiReport, emojiAppeal, emojiRoleapply, emojiPartner, emojiSupport].filter(Boolean);
      const emojiLine = emojiSet.length > 0 ? `\nEmojis applied: ${emojiSet.join(' ')}` : '';

      return interaction.reply({
        embeds: [successEmbed('Ticket Panel Sent', `The ticket panel has been sent to ${channel}.\n\nCategories: **Report Member**, **Punish Appeal**, **Role Apply**, **Partner**, **Support**${emojiLine}`)],
        ephemeral: true,
      });
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed('Failed', err.message)], ephemeral: true });
    }
  },
};
