import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed, modLogEmbed } from '../utils/embeds.js';
import { getConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption(o => o.setName('userid').setDescription('The user ID to unban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for unban').setRequired(false)),

  async execute(interaction) {
    const userId = interaction.options.getString('userid');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    try {
      const ban = await interaction.guild.bans.fetch(userId).catch(() => null);
      if (!ban) return interaction.reply({ embeds: [errorEmbed('Not Banned', 'That user is not banned.')], ephemeral: true });

      await interaction.guild.members.unban(userId, reason);

      await interaction.reply({ embeds: [successEmbed('User Unbanned', `**${ban.user.username}** has been unbanned.\n**Reason:** ${reason}`)] });

      const config = getConfig(interaction.guild.id);
      if (config.modlog.channel) {
        const logCh = interaction.guild.channels.cache.get(config.modlog.channel);
        if (logCh) {
          logCh.send({ embeds: [modLogEmbed({ action: 'UNBAN', user: ban.user, moderator: interaction.user, reason })] }).catch(() => {});
        }
      }
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Unban Failed', err.message)], ephemeral: true });
    }
  },
};
