import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed, modLogEmbed } from '../utils/embeds.js';
import { getConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName('user').setDescription('The user to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for kick').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')], ephemeral: true });
    if (!target.kickable) return interaction.reply({ embeds: [errorEmbed('Cannot Kick', 'I cannot kick this user.')], ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed('Invalid Action', 'You cannot kick yourself.')], ephemeral: true });

    try {
      await target.user.send({
        embeds: [{
          color: 0xF39C12,
          title: `👢 You have been kicked from ${interaction.guild.name}`,
          fields: [
            { name: 'Reason', value: reason },
            { name: 'Moderator', value: interaction.user.username },
          ],
          footer: { text: 'Ravage Guard • Moderation' },
          timestamp: new Date().toISOString(),
        }],
      }).catch(() => {});

      await target.kick(`${reason} | Kicked by ${interaction.user.username}`);

      await interaction.reply({
        embeds: [successEmbed('User Kicked', `**${target.user.username}** has been kicked.\n**Reason:** ${reason}`)],
      });

      const config = getConfig(interaction.guild.id);
      if (config.modlog.channel) {
        const logCh = interaction.guild.channels.cache.get(config.modlog.channel);
        if (logCh) {
          logCh.send({ embeds: [modLogEmbed({ action: 'KICK', user: target.user, moderator: interaction.user, reason })] }).catch(() => {});
        }
      }
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Kick Failed', `Failed to kick the user: ${err.message}`)], ephemeral: true });
    }
  },
};
