import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed, modLogEmbed } from '../utils/embeds.js';
import { getConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('The user to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for ban').setRequired(false))
    .addNumberOption(o => o.setName('days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7).setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const days = interaction.options.getNumber('days') || 0;

    if (!target) return interaction.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')], ephemeral: true });
    if (!target.bannable) return interaction.reply({ embeds: [errorEmbed('Cannot Ban', 'I cannot ban this user. They may have higher permissions than me.')], ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed('Invalid Action', 'You cannot ban yourself.')], ephemeral: true });

    try {
      await target.user.send({
        embeds: [{
          color: 0xE74C3C,
          title: `🔨 You have been banned from ${interaction.guild.name}`,
          fields: [
            { name: 'Reason', value: reason },
            { name: 'Moderator', value: interaction.user.username },
          ],
          footer: { text: 'Ravage Guard • Moderation' },
          timestamp: new Date().toISOString(),
        }],
      }).catch(() => {});

      await target.ban({ reason: `${reason} | Banned by ${interaction.user.username}`, deleteMessageSeconds: days * 86400 });

      await interaction.reply({
        embeds: [successEmbed('User Banned', `**${target.user.username}** has been banned.\n**Reason:** ${reason}`)],
      });

      const config = getConfig(interaction.guild.id);
      if (config.modlog.channel) {
        const logCh = interaction.guild.channels.cache.get(config.modlog.channel);
        if (logCh) {
          logCh.send({ embeds: [modLogEmbed({ action: 'BAN', user: target.user, moderator: interaction.user, reason })] }).catch(() => {});
        }
      }
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Ban Failed', `Failed to ban the user: ${err.message}`)], ephemeral: true });
    }
  },
};
