import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed, infoEmbed, modLogEmbed } from '../utils/embeds.js';
import { addWarning, getWarnings, clearWarnings, getConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warning management')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Warn a member')
        .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('View warnings for a user')
        .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('clear')
        .setDescription('Clear all warnings for a user')
        .addUserOption(o => o.setName('user').setDescription('User to clear').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const targetUser = interaction.options.getUser('user');

    if (sub === 'add') {
      const reason = interaction.options.getString('reason');
      addWarning(interaction.guild.id, targetUser.id, reason, interaction.user.id);
      const warnings = getWarnings(interaction.guild.id, targetUser.id);

      await targetUser.send({
        embeds: [{
          color: 0xF39C12,
          title: `You have received a warning in ${interaction.guild.name}`,
          fields: [
            { name: 'Reason', value: reason },
            { name: 'Moderator', value: interaction.user.username },
            { name: 'Total Warnings', value: `${warnings.length}` },
          ],
          footer: { text: 'Ravage Guard — Moderation' },
          timestamp: new Date().toISOString(),
        }],
      }).catch(() => {});

      await interaction.reply({
        embeds: [{
          color: 0xF39C12,
          title: 'Warning Issued',
          description: `**${targetUser.username}** has been warned. They now have **${warnings.length}** warning(s).`,
          fields: [{ name: 'Reason', value: reason }],
          footer: { text: 'Ravage Guard — Moderation' },
          timestamp: new Date().toISOString(),
        }],
      });

      const config = getConfig(interaction.guild.id);
      if (config.modlog.channel) {
        const logCh = interaction.guild.channels.cache.get(config.modlog.channel);
        if (logCh) {
          logCh.send({
            embeds: [modLogEmbed({
              action: 'WARN',
              user: targetUser,
              moderator: interaction.user,
              reason,
              extra: `Total warnings: ${warnings.length}`,
            })],
          }).catch(() => {});
        }
      }
    }

    if (sub === 'list') {
      const warnings = getWarnings(interaction.guild.id, targetUser.id);
      if (warnings.length === 0) {
        return interaction.reply({ embeds: [infoEmbed('No Warnings', `**${targetUser.username}** has no warnings.`)], ephemeral: true });
      }

      const fields = warnings.map((w, i) => ({
        name: `Warning #${i + 1} — ${new Date(w.timestamp).toLocaleDateString()}`,
        value: `**Reason:** ${w.reason}\n**Moderator:** <@${w.moderatorId}>`,
      }));

      await interaction.reply({
        embeds: [{
          color: 0xF39C12,
          title: `Warnings for ${targetUser.username}`,
          fields: fields.slice(0, 25),
          footer: { text: `Total: ${warnings.length} warning(s) | Ravage Guard` },
          timestamp: new Date().toISOString(),
        }],
        ephemeral: true,
      });
    }

    if (sub === 'clear') {
      clearWarnings(interaction.guild.id, targetUser.id);
      await interaction.reply({ embeds: [successEmbed('Warnings Cleared', `All warnings for **${targetUser.username}** have been cleared.`)] });
    }
  },
};
