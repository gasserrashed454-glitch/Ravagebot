import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed, modLogEmbed } from '../utils/embeds.js';
import { getConfig } from '../config.js';
import ms from 'ms';

export default {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Timeout (mute) a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('The user to mute').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 10m, 1h, 1d)').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for mute').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')], ephemeral: true });
    if (!target.moderatable) return interaction.reply({ embeds: [errorEmbed('Cannot Mute', 'I cannot mute this user.')], ephemeral: true });

    const duration = ms(durationStr);
    if (!duration || duration > 2419200000) {
      return interaction.reply({ embeds: [errorEmbed('Invalid Duration', 'Please provide a valid duration (max 28 days). Examples: `10m`, `1h`, `1d`')], ephemeral: true });
    }

    try {
      await target.timeout(duration, `${reason} | Muted by ${interaction.user.username}`);

      await target.user.send({
        embeds: [{
          color: 0xF39C12,
          title: `🔇 You have been muted in ${interaction.guild.name}`,
          fields: [
            { name: 'Duration', value: durationStr },
            { name: 'Reason', value: reason },
            { name: 'Moderator', value: interaction.user.username },
          ],
          footer: { text: 'Ravage Guard • Moderation' },
          timestamp: new Date().toISOString(),
        }],
      }).catch(() => {});

      await interaction.reply({
        embeds: [successEmbed('User Muted', `**${target.user.username}** has been muted for **${durationStr}**.\n**Reason:** ${reason}`)],
      });

      const config = getConfig(interaction.guild.id);
      if (config.modlog.channel) {
        const logCh = interaction.guild.channels.cache.get(config.modlog.channel);
        if (logCh) {
          logCh.send({ embeds: [modLogEmbed({ action: 'MUTE', user: target.user, moderator: interaction.user, reason, duration: durationStr })] }).catch(() => {});
        }
      }
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Mute Failed', `Failed to mute: ${err.message}`)], ephemeral: true });
    }
  },
};
