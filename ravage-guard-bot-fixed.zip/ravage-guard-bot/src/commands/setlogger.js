import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';
import { getConfig, saveConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('setlogger')
    .setDescription('Configure the server event logger')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('setup')
        .setDescription('Set the channel to receive log events')
        .addChannelOption(o => o.setName('channel').setDescription('Channel to send logs to').setRequired(true))
        .addBooleanOption(o => o.setName('deleted').setDescription('Log deleted messages (default: true)').setRequired(false))
        .addBooleanOption(o => o.setName('edited').setDescription('Log edited messages (default: true)').setRequired(false))
        .addBooleanOption(o => o.setName('ghostpings').setDescription('Log ghost pings (default: true)').setRequired(false)),
    )
    .addSubcommand(sub =>
      sub.setName('disable')
        .setDescription('Disable the logger'),
    )
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('View current logger configuration'),
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const config = getConfig(interaction.guild.id);

    if (sub === 'setup') {
      const channel = interaction.options.getChannel('channel');
      const logDeleted = interaction.options.getBoolean('deleted') ?? true;
      const logEdited = interaction.options.getBoolean('edited') ?? true;
      const logGhostPings = interaction.options.getBoolean('ghostpings') ?? true;

      config.logger.channel = channel.id;
      config.logger.logDeleted = logDeleted;
      config.logger.logEdited = logEdited;
      config.logger.logGhostPings = logGhostPings;
      saveConfig(interaction.guild.id, config);

      const lines = [
        `Logs will be sent to ${channel}.`,
        '',
        `Deleted messages: **${logDeleted ? 'On' : 'Off'}**`,
        `Edited messages: **${logEdited ? 'On' : 'Off'}**`,
        `Ghost pings: **${logGhostPings ? 'On' : 'Off'}**`,
      ];

      return interaction.reply({
        embeds: [successEmbed('Logger Configured', lines.join('\n'))],
        ephemeral: true,
      });
    }

    if (sub === 'disable') {
      config.logger.channel = null;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({
        embeds: [successEmbed('Logger Disabled', 'The event logger has been turned off.')],
        ephemeral: true,
      });
    }

    if (sub === 'status') {
      const logCh = config.logger.channel ? `<#${config.logger.channel}>` : 'Not set';
      return interaction.reply({
        embeds: [{
          color: 0x1ABC9C,
          title: 'Logger Configuration',
          fields: [
            { name: 'Log Channel', value: logCh, inline: true },
            { name: 'Deleted Messages', value: config.logger.logDeleted ? 'On' : 'Off', inline: true },
            { name: 'Edited Messages', value: config.logger.logEdited ? 'On' : 'Off', inline: true },
            { name: 'Ghost Pings', value: config.logger.logGhostPings ? 'On' : 'Off', inline: true },
          ],
          footer: { text: 'Ravage Guard — Logger' },
          timestamp: new Date().toISOString(),
        }],
        ephemeral: true,
      });
    }
  },
};
