import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';

export default {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set slowmode for a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addIntegerOption(o => o.setName('seconds').setDescription('Seconds between messages (0 to disable)').setMinValue(0).setMaxValue(21600).setRequired(true))
    .addChannelOption(o => o.setName('channel').setDescription('Channel (defaults to current)').setRequired(false)),

  async execute(interaction) {
    const seconds = interaction.options.getInteger('seconds');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    try {
      await channel.setRateLimitPerUser(seconds);
      if (seconds === 0) {
        return interaction.reply({ embeds: [successEmbed('Slowmode Disabled', `Slowmode has been disabled in ${channel}.`)] });
      }
      return interaction.reply({ embeds: [successEmbed('Slowmode Set', `Slowmode set to **${seconds}s** in ${channel}.`)] });
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed('Failed', err.message)], ephemeral: true });
    }
  },
};
