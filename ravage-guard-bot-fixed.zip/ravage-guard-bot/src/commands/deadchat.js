import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';
import { getConfig, saveConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('deadchat')
    .setDescription('Manage the dead chat revival system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('enable').setDescription('Enable dead chat detection'))
    .addSubcommand(sub => sub.setName('disable').setDescription('Disable dead chat detection'))
    .addSubcommand(sub =>
      sub.setName('setchannel')
        .setDescription('Set which channel to monitor')
        .addChannelOption(o => o.setName('channel').setDescription('Channel to watch').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('threshold')
        .setDescription('Set inactivity threshold (minutes)')
        .addIntegerOption(o => o.setName('minutes').setDescription('Minutes before sending revival message (default: 30)').setMinValue(5).setMaxValue(1440).setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('addmessage')
        .setDescription('Add a custom revival message')
        .addStringOption(o => o.setName('message').setDescription('Revival message to add').setRequired(true))
    )
    .addSubcommand(sub => sub.setName('status').setDescription('View dead chat settings')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const config = getConfig(interaction.guild.id);

    if (sub === 'enable') {
      if (!config.deadchat.channel) {
        return interaction.reply({ embeds: [errorEmbed('Not Configured', 'Please set a channel first with `/deadchat setchannel`.')], ephemeral: true });
      }
      config.deadchat.enabled = true;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Dead Chat Enabled', `Dead chat revival is now active for <#${config.deadchat.channel}>.\nThreshold: **${config.deadchat.threshold} minutes** of inactivity.`)] });
    }

    if (sub === 'disable') {
      config.deadchat.enabled = false;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Dead Chat Disabled', 'Dead chat revival has been disabled.')] });
    }

    if (sub === 'setchannel') {
      const channel = interaction.options.getChannel('channel');
      config.deadchat.channel = channel.id;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Channel Set', `${channel} will now be monitored for inactivity.`)] });
    }

    if (sub === 'threshold') {
      const minutes = interaction.options.getInteger('minutes');
      config.deadchat.threshold = minutes;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Threshold Updated', `Dead chat will trigger after **${minutes} minutes** of inactivity.`)] });
    }

    if (sub === 'addmessage') {
      const message = interaction.options.getString('message');
      config.deadchat.messages.push(message);
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Message Added', `Revival message added! You now have **${config.deadchat.messages.length}** messages.`)] });
    }

    if (sub === 'status') {
      const msgs = config.deadchat.messages.map((m, i) => `${i + 1}. ${m}`).join('\n') || 'None';
      return interaction.reply({
        embeds: [{
          color: 0x1ABC9C,
          title: '💀 Dead Chat Configuration',
          fields: [
            { name: 'Status', value: config.deadchat.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
            { name: 'Channel', value: config.deadchat.channel ? `<#${config.deadchat.channel}>` : 'Not set', inline: true },
            { name: 'Threshold', value: `${config.deadchat.threshold} minutes`, inline: true },
            { name: 'Revival Messages', value: msgs.slice(0, 1024), inline: false },
          ],
          footer: { text: 'Ravage Guard • Dead Chat' },
          timestamp: new Date().toISOString(),
        }],
        ephemeral: true,
      });
    }
  },
};
