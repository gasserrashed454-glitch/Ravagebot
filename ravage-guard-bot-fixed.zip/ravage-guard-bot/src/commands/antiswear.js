import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed, infoEmbed } from '../utils/embeds.js';
import { getConfig, saveConfig } from '../config.js';

export default {
  data: new SlashCommandBuilder()
    .setName('antiswear')
    .setDescription('Manage the anti-swear filter')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('enable').setDescription('Enable the anti-swear filter')
    )
    .addSubcommand(sub =>
      sub.setName('disable').setDescription('Disable the anti-swear filter')
    )
    .addSubcommand(sub =>
      sub.setName('addword')
        .setDescription('Add a word to the filter')
        .addStringOption(o => o.setName('word').setDescription('Word to add').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('removeword')
        .setDescription('Remove a word from the filter')
        .addStringOption(o => o.setName('word').setDescription('Word to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('setlog')
        .setDescription('Set the log channel for swear violations')
        .addChannelOption(o => o.setName('channel').setDescription('Log channel').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('toggle-dm')
        .setDescription('Toggle warning DMs to users who trigger the filter')
    )
    .addSubcommand(sub =>
      sub.setName('list').setDescription('View all filtered words and settings')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const config = getConfig(interaction.guild.id);

    if (sub === 'enable') {
      config.antiswear.enabled = true;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Anti-Swear Enabled', 'The anti-swear filter is now **active**.\nMessages containing banned words will be automatically deleted.')] });
    }

    if (sub === 'disable') {
      config.antiswear.enabled = false;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Anti-Swear Disabled', 'The anti-swear filter has been **disabled**.')] });
    }

    if (sub === 'addword') {
      const word = interaction.options.getString('word').toLowerCase();
      if (config.antiswear.words.includes(word)) {
        return interaction.reply({ embeds: [errorEmbed('Already Exists', `The word \`${word}\` is already in the filter.`)], ephemeral: true });
      }
      config.antiswear.words.push(word);
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Word Added', `\`${word}\` has been added to the filter. Total: **${config.antiswear.words.length}** words.`)] });
    }

    if (sub === 'removeword') {
      const word = interaction.options.getString('word').toLowerCase();
      if (!config.antiswear.words.includes(word)) {
        return interaction.reply({ embeds: [errorEmbed('Not Found', `The word \`${word}\` is not in the filter.`)], ephemeral: true });
      }
      config.antiswear.words = config.antiswear.words.filter(w => w !== word);
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Word Removed', `\`${word}\` has been removed from the filter.`)] });
    }

    if (sub === 'setlog') {
      const channel = interaction.options.getChannel('channel');
      config.antiswear.logChannel = channel.id;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Log Channel Set', `Anti-swear violations will now be logged in ${channel}.`)] });
    }

    if (sub === 'toggle-dm') {
      config.antiswear.warnDM = !config.antiswear.warnDM;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('DM Warnings Toggled', `Warning DMs are now **${config.antiswear.warnDM ? 'enabled' : 'disabled'}**.`)] });
    }

    if (sub === 'list') {
      const wordList = config.antiswear.words.map(w => `\`${w}\``).join(', ') || 'None';
      return interaction.reply({
        embeds: [{
          color: 0x1ABC9C,
          title: '🧹 Anti-Swear Configuration',
          fields: [
            { name: 'Status', value: config.antiswear.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
            { name: 'DM Warnings', value: config.antiswear.warnDM ? '✅ On' : '❌ Off', inline: true },
            { name: 'Log Channel', value: config.antiswear.logChannel ? `<#${config.antiswear.logChannel}>` : 'Not set', inline: true },
            { name: `Filtered Words (${config.antiswear.words.length})`, value: wordList.slice(0, 1024), inline: false },
          ],
          footer: { text: 'Ravage Guard • Anti-Swear' },
          timestamp: new Date().toISOString(),
        }],
        ephemeral: true,
      });
    }
  },
};
