import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';
import { getConfig, saveConfig } from '../config.js';
import { sendTicketPanel } from '../systems/tickets.js';

export default {
  data: new SlashCommandBuilder()
    .setName('tickets')
    .setDescription('Manage the ticket system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub.setName('enable').setDescription('Enable the ticket system'))
    .addSubcommand(sub => sub.setName('disable').setDescription('Disable the ticket system'))
    .addSubcommand(sub =>
      sub.setName('setup')
        .setDescription('Quick setup for tickets')
        .addChannelOption(o => o.setName('category').setDescription('Category for ticket channels').setRequired(true))
        .addRoleOption(o => o.setName('supportrole').setDescription('Role that can see tickets').setRequired(true))
        .addChannelOption(o => o.setName('logchannel').setDescription('Channel to log ticket events').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('panel')
        .setDescription('Send the ticket panel to a channel')
        .addChannelOption(o => o.setName('channel').setDescription('Channel to send the panel in').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('setwelcome')
        .setDescription('Set the welcome message for new tickets')
        .addStringOption(o => o.setName('message').setDescription('Welcome message').setRequired(true))
    )
    .addSubcommand(sub => sub.setName('status').setDescription('View ticket system configuration')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const config = getConfig(interaction.guild.id);

    if (sub === 'enable') {
      if (!config.tickets.category) {
        return interaction.reply({ embeds: [errorEmbed('Not Configured', 'Please run `/tickets setup` first.')], ephemeral: true });
      }
      config.tickets.enabled = true;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Tickets Enabled', 'The ticket system is now active!')] });
    }

    if (sub === 'disable') {
      config.tickets.enabled = false;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Tickets Disabled', 'The ticket system has been disabled.')] });
    }

    if (sub === 'setup') {
      const category = interaction.options.getChannel('category');
      const supportRole = interaction.options.getRole('supportrole');
      const logChannel = interaction.options.getChannel('logchannel');

      config.tickets.category = category.id;
      config.tickets.supportRole = supportRole.id;
      config.tickets.enabled = true;
      if (logChannel) config.tickets.logChannel = logChannel.id;

      saveConfig(interaction.guild.id, config);

      return interaction.reply({
        embeds: [successEmbed('Ticket System Configured', `✅ Setup complete!\n\n**Category:** ${category}\n**Support Role:** ${supportRole}\n**Log Channel:** ${logChannel || 'Not set'}\n\nNow use \`/tickets panel\` to send the ticket panel to a channel.`)],
      });
    }

    if (sub === 'panel') {
      const channel = interaction.options.getChannel('channel');
      try {
        await sendTicketPanel(channel, interaction.guild);
        return interaction.reply({ embeds: [successEmbed('Panel Sent', `The ticket panel has been sent to ${channel}.`)], ephemeral: true });
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed('Failed', err.message)], ephemeral: true });
      }
    }

    if (sub === 'setwelcome') {
      const message = interaction.options.getString('message');
      config.tickets.openMessage = message;
      saveConfig(interaction.guild.id, config);
      return interaction.reply({ embeds: [successEmbed('Welcome Message Updated', `New tickets will show:\n> ${message}`)] });
    }

    if (sub === 'status') {
      return interaction.reply({
        embeds: [{
          color: 0x1ABC9C,
          title: '🎫 Ticket System Configuration',
          fields: [
            { name: 'Status', value: config.tickets.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
            { name: 'Category', value: config.tickets.category ? `<#${config.tickets.category}>` : 'Not set', inline: true },
            { name: 'Support Role', value: config.tickets.supportRole ? `<@&${config.tickets.supportRole}>` : 'Not set', inline: true },
            { name: 'Log Channel', value: config.tickets.logChannel ? `<#${config.tickets.logChannel}>` : 'Not set', inline: true },
            { name: 'Panel Channel', value: config.tickets.panelChannel ? `<#${config.tickets.panelChannel}>` : 'Not set', inline: true },
            { name: 'Welcome Message', value: config.tickets.openMessage || 'Default', inline: false },
          ],
          footer: { text: 'Ravage Guard • Tickets' },
          timestamp: new Date().toISOString(),
        }],
        ephemeral: true,
      });
    }
  },
};
