import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, '..', 'data');

if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });

function getConfigPath(guildId) {
  return path.join(DATA_DIR, `${guildId}.json`);
}

const defaultConfig = {
  antiswear: {
    enabled: false,
    words: ['fuck', 'shit', 'bitch', 'ass', 'cunt', 'dick', 'pussy', 'bastard', 'nigga', 'nigger', 'faggot'],
    action: 'delete',
    warnDM: true,
    logChannel: null,
  },
  antinuke: {
    enabled: false,
    logChannel: null,
    whitelistedUsers: [],
    punishAction: 'ban',
    thresholds: {
      bans: 3,
      kicks: 5,
      channelDeletes: 3,
      roleDeletes: 3,
      webhookCreates: 3,
    },
  },
  deadchat: {
    enabled: false,
    channel: null,
    threshold: 30,
    messages: [
      'This chat is dead. Say something!',
      'Hello? Anyone there?',
      'Chat fell asleep. Wake it up!',
      'Let\'s get this chat going again!',
    ],
  },
  tickets: {
    enabled: false,
    category: null,
    logChannel: null,
    supportRole: null,
    panelChannel: null,
    openMessage: 'Thank you for opening a ticket. Our support team will be with you shortly.',
  },
  modlog: {
    channel: null,
  },
  logger: {
    channel: null,
    logDeleted: true,
    logEdited: true,
    logGhostPings: true,
  },
  warnings: {},
  apply: {
    panelChannel: null,
    logChannel: null,
    acceptRole: null,
    buttonEmoji: null,
  },
  ticketEmojis: {
    report: null,
    appeal: null,
    roleapply: null,
    partner: null,
    support: null,
  },
};

export function getConfig(guildId) {
  const filePath = getConfigPath(guildId);
  if (!existsSync(filePath)) {
    return structuredClone(defaultConfig);
  }
  try {
    const raw = readFileSync(filePath, 'utf-8');
    const stored = JSON.parse(raw);
    return deepMerge(structuredClone(defaultConfig), stored);
  } catch {
    return structuredClone(defaultConfig);
  }
}

export function saveConfig(guildId, config) {
  writeFileSync(getConfigPath(guildId), JSON.stringify(config, null, 2));
}

function deepMerge(target, source) {
  for (const key of Object.keys(source)) {
    if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
      if (!target[key]) target[key] = {};
      deepMerge(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  }
  return target;
}

export function addWarning(guildId, userId, reason, moderatorId) {
  const config = getConfig(guildId);
  if (!config.warnings[userId]) config.warnings[userId] = [];
  const warning = {
    id: Date.now(),
    reason,
    moderatorId,
    timestamp: new Date().toISOString(),
  };
  config.warnings[userId].push(warning);
  saveConfig(guildId, config);
  return warning;
}

export function getWarnings(guildId, userId) {
  const config = getConfig(guildId);
  return config.warnings[userId] || [];
}

export function clearWarnings(guildId, userId) {
  const config = getConfig(guildId);
  config.warnings[userId] = [];
  saveConfig(guildId, config);
}
