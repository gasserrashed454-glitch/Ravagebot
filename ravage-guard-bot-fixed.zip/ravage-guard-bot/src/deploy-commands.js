import { REST, Routes } from 'discord.js';
import { readdirSync } from 'fs';
import { fileURLToPath } from 'url';
import path from 'path';
import 'dotenv/config';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const commands = [];
const commandFiles = readdirSync(path.join(__dirname, 'commands')).filter(f => f.endsWith('.js'));

for (const file of commandFiles) {
  const cmd = await import(`./commands/${file}`);
  if (cmd.default?.data) {
    commands.push(cmd.default.data.toJSON());
  }
}

const rest = new REST().setToken(process.env.DISCORD_BOT_TOKEN);
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

console.log(`📡 Registering ${commands.length} slash commands...`);

try {
  if (guildId) {
    await rest.put(
      Routes.applicationGuildCommands(clientId, guildId),
      { body: commands },
    );
    console.log(`✅ Successfully registered ${commands.length} commands to guild ${guildId} (instant).`);
  } else {
    await rest.put(
      Routes.applicationCommands(clientId),
      { body: commands },
    );
    console.log(`✅ Successfully registered ${commands.length} commands globally (may take up to 1 hour to appear).`);
  }
  console.log('Commands:', commands.map(c => `/${c.name}`).join(', '));
} catch (err) {
  console.error('❌ Failed to register commands:', err);
}
