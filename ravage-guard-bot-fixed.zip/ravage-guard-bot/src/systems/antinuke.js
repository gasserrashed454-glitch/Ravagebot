import { getConfig } from '../config.js';
import { modLogEmbed } from '../utils/embeds.js';

const actionTracker = new Map();

function track(guildId, userId, action, threshold) {
  const key = `${guildId}-${userId}-${action}`;
  const now = Date.now();
  const window = 10000;

  if (!actionTracker.has(key)) actionTracker.set(key, []);
  const times = actionTracker.get(key).filter(t => now - t < window);
  times.push(now);
  actionTracker.set(key, times);

  setTimeout(() => {
    const current = actionTracker.get(key) || [];
    actionTracker.set(key, current.filter(t => Date.now() - t < window));
  }, window);

  return times.length >= threshold;
}

async function punish(guild, userId, action, reason, logChannel, client) {
  const member = guild.members.cache.get(userId);
  if (!member) return;

  if (action === 'ban') {
    try { await guild.members.ban(userId, { reason: `[Anti-Nuke] ${reason}` }); } catch {}
  } else if (action === 'kick') {
    try { await member.kick(`[Anti-Nuke] ${reason}`); } catch {}
  } else if (action === 'derank') {
    try { await member.roles.set([], `[Anti-Nuke] ${reason}`); } catch {}
  }

  if (logChannel) {
    const ch = guild.channels.cache.get(logChannel);
    if (ch) {
      const embed = modLogEmbed({
        action: 'ANTINUKE',
        user: member.user,
        moderator: client.user,
        reason,
        extra: `Punishment: ${action.toUpperCase()}`,
      });
      ch.send({ embeds: [embed] }).catch(() => {});
    }
  }
}

export async function handleChannelDelete(channel, client) {
  if (!channel.guild) return;
  const config = getConfig(channel.guild.id);
  if (!config.antinuke.enabled) return;

  const audit = await channel.guild.fetchAuditLogs({ type: 12, limit: 1 }).catch(() => null);
  const entry = audit?.entries.first();
  if (!entry) return;

  const executor = entry.executor;
  if (!executor || executor.id === client.user.id) return;
  if (config.antinuke.whitelistedUsers.includes(executor.id)) return;

  const threshold = config.antinuke.thresholds.channelDeletes;
  const triggered = track(channel.guild.id, executor.id, 'channelDelete', threshold);
  if (triggered) {
    await punish(channel.guild, executor.id, config.antinuke.punishAction, `Mass channel deletion (${threshold}+ in 10s)`, config.antinuke.logChannel, client);
  }
}

export async function handleGuildBanAdd(ban, client) {
  const guild = ban.guild;
  const config = getConfig(guild.id);
  if (!config.antinuke.enabled) return;

  const audit = await guild.fetchAuditLogs({ type: 22, limit: 1 }).catch(() => null);
  const entry = audit?.entries.first();
  if (!entry) return;

  const executor = entry.executor;
  if (!executor || executor.id === client.user.id) return;
  if (config.antinuke.whitelistedUsers.includes(executor.id)) return;

  const threshold = config.antinuke.thresholds.bans;
  const triggered = track(guild.id, executor.id, 'ban', threshold);
  if (triggered) {
    await punish(guild, executor.id, config.antinuke.punishAction, `Mass banning (${threshold}+ in 10s)`, config.antinuke.logChannel, client);
  }
}

export async function handleGuildMemberRemove(member, client) {
  const guild = member.guild;
  const config = getConfig(guild.id);
  if (!config.antinuke.enabled) return;

  const audit = await guild.fetchAuditLogs({ type: 20, limit: 1 }).catch(() => null);
  const entry = audit?.entries.first();
  if (!entry) return;

  const executor = entry.executor;
  if (!executor || executor.id === client.user.id) return;
  if (config.antinuke.whitelistedUsers.includes(executor.id)) return;

  const threshold = config.antinuke.thresholds.kicks;
  const triggered = track(guild.id, executor.id, 'kick', threshold);
  if (triggered) {
    await punish(guild, executor.id, config.antinuke.punishAction, `Mass kicking (${threshold}+ in 10s)`, config.antinuke.logChannel, client);
  }
}

export async function handleRoleDelete(role, client) {
  const guild = role.guild;
  const config = getConfig(guild.id);
  if (!config.antinuke.enabled) return;

  const audit = await guild.fetchAuditLogs({ type: 32, limit: 1 }).catch(() => null);
  const entry = audit?.entries.first();
  if (!entry) return;

  const executor = entry.executor;
  if (!executor || executor.id === client.user.id) return;
  if (config.antinuke.whitelistedUsers.includes(executor.id)) return;

  const threshold = config.antinuke.thresholds.roleDeletes;
  const triggered = track(guild.id, executor.id, 'roleDelete', threshold);
  if (triggered) {
    await punish(guild, executor.id, config.antinuke.punishAction, `Mass role deletion (${threshold}+ in 10s)`, config.antinuke.logChannel, client);
  }
}

export async function handleWebhookCreate(channel, client) {
  if (!channel.guild) return;
  const config = getConfig(channel.guild.id);
  if (!config.antinuke.enabled) return;

  const audit = await channel.guild.fetchAuditLogs({ type: 50, limit: 1 }).catch(() => null);
  const entry = audit?.entries.first();
  if (!entry) return;

  const executor = entry.executor;
  if (!executor || executor.id === client.user.id) return;
  if (config.antinuke.whitelistedUsers.includes(executor.id)) return;

  const threshold = config.antinuke.thresholds.webhookCreates;
  const triggered = track(channel.guild.id, executor.id, 'webhook', threshold);
  if (triggered) {
    await punish(channel.guild, executor.id, config.antinuke.punishAction, `Mass webhook creation (${threshold}+ in 10s)`, config.antinuke.logChannel, client);
  }
}
