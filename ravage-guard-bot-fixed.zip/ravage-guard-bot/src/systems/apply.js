import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from 'discord.js';
import { getConfig } from '../config.js';

const BRAND_COLOR = 0x1ABC9C;
const EXPIRY_MS = 60 * 60 * 1000; // 1 hour

const QUESTIONS = [
  'What is your Discord username and ID?',
  'How old are you?',
  'What country/timezone are you in?',
  'Why do you want to become staff on this server?',
  'What experience do you have as staff?',
  'How active can you be each day (hours)?',
  'How would you deal with someone breaking rules?',
  'Do you actively play on our SMP server? If yes, how often?',
  'What is your in-game Minecraft username?',
  'Are you willing to help players in-game as well as on Discord?',
  'Do you have any ideas to improve the SMP or make it more active?',
];

// userId -> { guildId, answers, currentQuestion, timeout }
export const pendingApplications = new Map();

export async function sendApplyPanel(channel, buttonEmoji = null) {
  const embed = new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle('Join the Staff Team')
    .setDescription(
      "We're looking for active, friendly and dedicated members to help keep the server running smoothly.\n\nClick the button below to submit your application — it only takes a few minutes.",
    )
    .setFooter({ text: 'Ravage Guard — Staff Applications' });

  const btn = new ButtonBuilder()
    .setCustomId('apply_open')
    .setLabel('Apply Now')
    .setStyle(ButtonStyle.Primary);

  if (buttonEmoji) btn.setEmoji(buttonEmoji);

  const row = new ActionRowBuilder().addComponents(btn);

  await channel.send({ embeds: [embed], components: [row] });
}

export async function openApplyDM(interaction) {
  const userId = interaction.user.id;

  if (pendingApplications.has(userId)) {
    return interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xED4245)
          .setTitle('Application In Progress')
          .setDescription('You already have an application in progress. Check your DMs to continue.')
          .setFooter({ text: 'Ravage Guard — Staff Applications' }),
      ],
      ephemeral: true,
    });
  }

  // Try to open DM
  let dmChannel;
  try {
    dmChannel = await interaction.user.createDM();
  } catch {
    return interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xED4245)
          .setTitle('Could Not Open DM')
          .setDescription('Please enable DMs from server members and try again.')
          .setFooter({ text: 'Ravage Guard — Staff Applications' }),
      ],
      ephemeral: true,
    });
  }

  // Send opening message
  await dmChannel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(BRAND_COLOR)
        .setTitle('Application Started')
        .setDescription(
          'Please answer the questions below by sending a message to the bot with your response.\n\n' +
          `You have **1 hour** to complete the application before it expires.\n\n` +
          `There are **${QUESTIONS.length} questions** in total.`,
        )
        .setFooter({ text: 'Ravage Guard — Staff Applications' }),
    ],
  }).catch(() => {});

  // Start tracking
  const timeout = setTimeout(() => expireApplication(userId, interaction.client), EXPIRY_MS);

  pendingApplications.set(userId, {
    guildId: interaction.guild.id,
    answers: [],
    currentQuestion: 0,
    timeout,
  });

  // Send first question
  await sendQuestion(dmChannel, userId);

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(BRAND_COLOR)
        .setTitle('Application Started')
        .setDescription('Check your DMs to answer the application questions.')
        .setFooter({ text: 'Ravage Guard — Staff Applications' }),
    ],
    ephemeral: true,
  });
}

async function sendQuestion(dmChannel, userId) {
  const state = pendingApplications.get(userId);
  if (!state) return;

  const qIndex = state.currentQuestion;
  const total = QUESTIONS.length;
  const question = QUESTIONS[qIndex];

  await dmChannel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(BRAND_COLOR)
        .setTitle('Staff Application')
        .setDescription(`**${qIndex + 1}/${total}.** ${question}`)
        .setFooter({ text: 'To answer this question, please send a message to the bot with your response.' }),
    ],
  }).catch(() => {});
}

export async function handleApplyDMResponse(message, client) {
  const userId = message.author.id;
  const state = pendingApplications.get(userId);
  if (!state) return;

  // Record answer
  state.answers.push({
    question: QUESTIONS[state.currentQuestion],
    answer: message.content.trim(),
  });
  state.currentQuestion++;

  // Check if done
  if (state.currentQuestion >= QUESTIONS.length) {
    clearTimeout(state.timeout);
    pendingApplications.delete(userId);
    await submitApplication(message.author, state, client);
    return;
  }

  // Next question
  await sendQuestion(message.channel, userId);
}

async function submitApplication(user, state, client) {
  const guild = client.guilds.cache.get(state.guildId);
  if (!guild) return;

  const config = getConfig(state.guildId);
  const appConfig = config.apply || {};

  const fields = state.answers.map((a, i) => ({
    name: `${i + 1}. ${a.question}`,
    value: a.answer.slice(0, 1024) || '*No answer*',
    inline: false,
  }));

  const embed = new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle('New Staff Application')
    .setThumbnail(user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: 'Applicant', value: `<@${user.id}> (${user.username})`, inline: true },
      { name: 'Submitted', value: new Date().toUTCString(), inline: true },
      { name: '\u200B', value: '\u200B', inline: false },
      ...fields,
    )
    .setFooter({ text: `User ID: ${user.id} | Ravage Guard — Staff Applications` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`apply_accept_${user.id}`)
      .setLabel('Accept')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`apply_decline_${user.id}`)
      .setLabel('Decline')
      .setStyle(ButtonStyle.Danger),
  );

  if (appConfig.logChannel) {
    const logCh = guild.channels.cache.get(appConfig.logChannel);
    if (logCh) {
      await logCh.send({ embeds: [embed], components: [row] }).catch(() => {});
    }
  }

  // Confirm to applicant
  await user.send({
    embeds: [
      new EmbedBuilder()
        .setColor(BRAND_COLOR)
        .setTitle('Application Submitted')
        .setDescription('Your application has been submitted to the staff team. You will be notified when a decision is made.')
        .setFooter({ text: 'Ravage Guard — Staff Applications' }),
    ],
  }).catch(() => {});
}

async function expireApplication(userId, client) {
  const state = pendingApplications.get(userId);
  if (!state) return;

  pendingApplications.delete(userId);

  const user = await client.users.fetch(userId).catch(() => null);
  if (user) {
    await user.send({
      embeds: [
        new EmbedBuilder()
          .setColor(0xED4245)
          .setTitle('Application Expired')
          .setDescription('Your staff application has expired after 1 hour of inactivity. You can click Apply Now in the server to start again.')
          .setFooter({ text: 'Ravage Guard — Staff Applications' }),
      ],
    }).catch(() => {});
  }
}

export async function openAcceptReasonModal(interaction) {
  const userId = interaction.customId.replace('apply_accept_', '');

  const modal = new ModalBuilder()
    .setCustomId(`apply_accept_reason_${userId}`)
    .setTitle('Accept Application');

  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('accept_reason')
        .setLabel('Reason for accepting')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMaxLength(500)
        .setPlaceholder('Why is this applicant being accepted?'),
    ),
  );

  await interaction.showModal(modal);
}

export async function openDeclineReasonModal(interaction) {
  const userId = interaction.customId.replace('apply_decline_', '');

  const modal = new ModalBuilder()
    .setCustomId(`apply_decline_reason_${userId}`)
    .setTitle('Decline Application');

  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('decline_reason')
        .setLabel('Reason for declining')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMaxLength(500)
        .setPlaceholder('Why is this applicant being declined?'),
    ),
  );

  await interaction.showModal(modal);
}

export async function handleApplyAcceptWithReason(interaction) {
  const userId = interaction.customId.replace('apply_accept_reason_', '');
  const reason = interaction.fields.getTextInputValue('accept_reason');
  const config = getConfig(interaction.guild.id);
  const appConfig = config.apply || {};

  const member = await interaction.guild.members.fetch(userId).catch(() => null);

  if (appConfig.acceptRole && member) {
    await member.roles.add(appConfig.acceptRole, `Staff application accepted by ${interaction.user.username} — ${reason}`).catch(() => {});
  }

  const acceptedEmbed = EmbedBuilder.from(interaction.message.embeds[0])
    .setColor(0x57F287)
    .setTitle('Application — Accepted')
    .addFields(
      { name: 'Decision', value: `Accepted by <@${interaction.user.id}>`, inline: true },
      { name: 'Reason', value: reason, inline: false },
    );

  await interaction.message.edit({ embeds: [acceptedEmbed], components: [] });

  if (member) {
    await member.send({
      embeds: [
        new EmbedBuilder()
          .setColor(0x57F287)
          .setTitle('Application Accepted')
          .setDescription(`Your staff application for **${interaction.guild.name}** has been accepted.\n\nWelcome to the team — a staff member will brief you shortly.`)
          .addFields({ name: 'Reason', value: reason, inline: false })
          .setFooter({ text: 'Ravage Guard — Staff Applications' }),
      ],
    }).catch(() => {});
  }

  await interaction.reply({ content: `Application from <@${userId}> accepted. Reason: ${reason}`, ephemeral: true });
}

export async function handleApplyDeclineWithReason(interaction) {
  const userId = interaction.customId.replace('apply_decline_reason_', '');
  const reason = interaction.fields.getTextInputValue('decline_reason');

  const member = await interaction.guild.members.fetch(userId).catch(() => null);

  const declinedEmbed = EmbedBuilder.from(interaction.message.embeds[0])
    .setColor(0xED4245)
    .setTitle('Application — Declined')
    .addFields(
      { name: 'Decision', value: `Declined by <@${interaction.user.id}>`, inline: true },
      { name: 'Reason', value: reason, inline: false },
    );

  await interaction.message.edit({ embeds: [declinedEmbed], components: [] });

  if (member) {
    await member.send({
      embeds: [
        new EmbedBuilder()
          .setColor(0xED4245)
          .setTitle('Application Declined')
          .setDescription(`Unfortunately, your staff application for **${interaction.guild.name}** was not accepted this time.\n\nFeel free to apply again in the future.`)
          .addFields({ name: 'Reason', value: reason, inline: false })
          .setFooter({ text: 'Ravage Guard — Staff Applications' }),
      ],
    }).catch(() => {});
  }

  await interaction.reply({ content: `Application from <@${userId}> declined. Reason: ${reason}`, ephemeral: true });
}
