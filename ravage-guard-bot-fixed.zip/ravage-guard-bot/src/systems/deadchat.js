import { getConfig } from '../config.js';

const lastMessageTime = new Map();
const deadChatTimers = new Map();

export function trackMessage(message) {
  if (!message.guild || message.author.bot) return;
  const config = getConfig(message.guild.id);
  if (!config.deadchat.enabled || !config.deadchat.channel) return;
  if (message.channelId !== config.deadchat.channel) return;

  const key = `${message.guild.id}-${message.channelId}`;
  lastMessageTime.set(key, Date.now());

  if (deadChatTimers.has(key)) {
    clearTimeout(deadChatTimers.get(key));
  }

  const thresholdMs = (config.deadchat.threshold || 30) * 60 * 1000;

  const timer = setTimeout(async () => {
    const cfg = getConfig(message.guild.id);
    if (!cfg.deadchat.enabled || !cfg.deadchat.channel) return;

    const channel = message.guild.channels.cache.get(cfg.deadchat.channel);
    if (!channel) return;

    const msgs = cfg.deadchat.messages || [];
    const revival = msgs[Math.floor(Math.random() * msgs.length)];

    await channel.send({
      embeds: [{
        color: 0x1ABC9C,
        title: '💀 Dead Chat Revival',
        description: revival,
        footer: { text: 'Ravage Guard • Dead Chat System' },
        timestamp: new Date().toISOString(),
      }],
    }).catch(() => {});

    deadChatTimers.delete(key);
  }, thresholdMs);

  deadChatTimers.set(key, timer);
}

export function initDeadChatTimers(client) {
  for (const guild of client.guilds.cache.values()) {
    const config = getConfig(guild.id);
    if (!config.deadchat.enabled || !config.deadchat.channel) continue;

    const channel = guild.channels.cache.get(config.deadchat.channel);
    if (!channel) continue;

    const key = `${guild.id}-${config.deadchat.channel}`;
    if (deadChatTimers.has(key)) clearTimeout(deadChatTimers.get(key));

    const thresholdMs = (config.deadchat.threshold || 30) * 60 * 1000;
    const timer = setTimeout(async () => {
      const cfg = getConfig(guild.id);
      if (!cfg.deadchat.enabled || !cfg.deadchat.channel) return;
      const ch = guild.channels.cache.get(cfg.deadchat.channel);
      if (!ch) return;
      const msgs = cfg.deadchat.messages || [];
      const revival = msgs[Math.floor(Math.random() * msgs.length)];
      await ch.send({
        embeds: [{
          color: 0x1ABC9C,
          title: '💀 Dead Chat Revival',
          description: revival,
          footer: { text: 'Ravage Guard • Dead Chat System' },
          timestamp: new Date().toISOString(),
        }],
      }).catch(() => {});
    }, thresholdMs);

    deadChatTimers.set(key, timer);
  }
}
