import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
} from 'discord.js';
import { getConfig, saveConfig } from '../config.js';
import { ticketEmbed, ticketPanelEmbed, successEmbed, errorEmbed } from '../utils/embeds.js';

const BRAND_COLOR = 0x1ABC9C;

const TICKET_CATEGORIES = {
  ticket_open_report:    { label: 'Report Member',  color: 0xE74C3C, style: ButtonStyle.Danger },
  ticket_open_appeal:    { label: 'Punish Appeal',  color: 0x1ABC9C, style: ButtonStyle.Primary },
  ticket_open_roleapply: { label: 'Role Apply',     color: 0x95A5A6, style: ButtonStyle.Secondary },
  ticket_open_partner:   { label: 'Partner',        color: 0xF1C40F, style: ButtonStyle.Secondary },
  ticket_open_support:   { label: 'Support',        color: 0x2ECC71, style: ButtonStyle.Success },
};

function makeBtn(customId, label, style, emoji) {
  const btn = new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);
  if (emoji) btn.setEmoji(emoji);
  return btn;
}

export async function sendAdvancedTicketPanel(channel, guild) {
  const config = getConfig(guild.id);
  config.tickets.panelChannel = channel.id;
  saveConfig(guild.id, config);

  const e = config.ticketEmojis || {};

  const embed = new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle('Need Help? Open a Ticket')
    .setDescription(
      'A staff member will be with you shortly, so please be patient.\n' +
      'Tickets that stay empty for **1 hour** will be automatically closed, and **spamming tickets is not allowed**.',
    )
    .setFooter({ text: 'Ravage Guard — Support System' })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    makeBtn('ticket_open_report',    'Report Member', ButtonStyle.Danger,    e.report),
    makeBtn('ticket_open_appeal',    'Punish Appeal', ButtonStyle.Primary,   e.appeal),
    makeBtn('ticket_open_roleapply', 'Role Apply',    ButtonStyle.Secondary, e.roleapply),
    makeBtn('ticket_open_partner',   'Partner',       ButtonStyle.Secondary, e.partner),
  );

  const row2 = new ActionRowBuilder().addComponents(
    makeBtn('ticket_open_support', 'Support', ButtonStyle.Success, e.support),
  );

  await channel.send({ embeds: [embed], components: [row1, row2] });
}

export async function sendTicketPanel(channel, guild) {
  const config = getConfig(guild.id);
  config.tickets.panelChannel = channel.id;
  saveConfig(guild.id, config);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_open')
      .setLabel('Open a Ticket')
      .setStyle(ButtonStyle.Primary),
  );

  await channel.send({
    embeds: [ticketPanelEmbed()],
    components: [row],
  });
}

export async function openCategorizedTicket(interaction, categoryId) {
  const guild = interaction.guild;
  const config = getConfig(guild.id);
  const cat = TICKET_CATEGORIES[categoryId];

  if (!config.tickets.enabled) {
    return interaction.reply({ embeds: [errorEmbed('Tickets Disabled', 'The ticket system is not enabled.')], ephemeral: true });
  }

  const prefix = `${cat.label.toLowerCase().replace(/\s+/g, '-')}-${interaction.user.username.toLowerCase()}`;
  const existing = guild.channels.cache.find(c => c.topic === `Ticket for ${interaction.user.id} | ${cat.label}`);
  if (existing) {
    return interaction.reply({ embeds: [errorEmbed('Already Open', `You already have an open ${cat.label} ticket: ${existing}`)], ephemeral: true });
  }

  const ticketNumber = Date.now().toString().slice(-6);
  const channelName = prefix.slice(0, 100);

  const overwrites = [
    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
  ];

  if (config.tickets.supportRole) {
    overwrites.push({
      id: config.tickets.supportRole,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }

  const ticketChannel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: config.tickets.category || null,
    topic: `Ticket for ${interaction.user.id} | ${cat.label}`,
    permissionOverwrites: overwrites,
  });

  const embed = new EmbedBuilder()
    .setColor(cat.color)
    .setTitle(`${cat.label} — Ticket #${ticketNumber}`)
    .setDescription(`Hey <@${interaction.user.id}>, thanks for opening a **${cat.label}** ticket.\n\nPlease describe your issue and a staff member will assist you shortly.`)
    .setFooter({ text: 'Ravage Guard — Support' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close Ticket').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setStyle(ButtonStyle.Secondary),
  );

  await ticketChannel.send({ embeds: [embed], components: [row] });

  await interaction.reply({
    embeds: [successEmbed('Ticket Opened', `Your **${cat.label}** ticket has been created: ${ticketChannel}`)],
    ephemeral: true,
  });
}

export async function openTicket(interaction) {
  const guild = interaction.guild;
  const config = getConfig(guild.id);

  if (!config.tickets.enabled) {
    return interaction.reply({ embeds: [errorEmbed('Tickets Disabled', 'The ticket system is not enabled.')], ephemeral: true });
  }

  const existing = guild.channels.cache.find(c => c.topic === `Ticket for ${interaction.user.id}`);
  if (existing) {
    return interaction.reply({ embeds: [errorEmbed('Already Open', `You already have an open ticket: ${existing}`)], ephemeral: true });
  }

  const ticketNumber = Date.now().toString().slice(-6);
  const channelName = `ticket-${interaction.user.username.toLowerCase()}`.slice(0, 100);

  const overwrites = [
    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
  ];

  if (config.tickets.supportRole) {
    overwrites.push({
      id: config.tickets.supportRole,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }

  const ticketChannel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: config.tickets.category || null,
    topic: `Ticket for ${interaction.user.id}`,
    permissionOverwrites: overwrites,
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close Ticket').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setStyle(ButtonStyle.Secondary),
  );

  await ticketChannel.send({
    content: `<@${interaction.user.id}>`,
    embeds: [ticketEmbed(ticketNumber, `<@${interaction.user.id}>`)],
    components: [row],
  });

  await interaction.reply({
    embeds: [successEmbed('Ticket Opened', `Your ticket has been created: ${ticketChannel}`)],
    ephemeral: true,
  });
}

async function collectTranscript(channel) {
  const allMessages = [];
  let lastId = null;

  while (true) {
    const options = { limit: 100 };
    if (lastId) options.before = lastId;

    const fetched = await channel.messages.fetch(options).catch(() => null);
    if (!fetched || fetched.size === 0) break;

    for (const msg of fetched.values()) {
      allMessages.push(msg);
    }

    lastId = fetched.last().id;
    if (fetched.size < 100) break;
  }

  allMessages.reverse();

  const lines = [];
  for (const msg of allMessages) {
    const time = new Date(msg.createdTimestamp).toLocaleString('en-US', { timeZone: 'UTC' });
    const author = msg.author?.username || 'Unknown';
    let content = msg.content || '';

    if (msg.embeds.length > 0) {
      const embedInfo = msg.embeds.map(e => {
        const parts = [];
        if (e.title) parts.push(e.title);
        if (e.description) parts.push(e.description);
        return parts.join(' — ');
      }).join(' | ');
      if (embedInfo) content += (content ? ' ' : '') + `[Embed: ${embedInfo}]`;
    }

    if (msg.attachments.size > 0) {
      const attachInfo = msg.attachments.map(a => a.url).join(', ');
      content += (content ? ' ' : '') + `[Attachments: ${attachInfo}]`;
    }

    if (content) {
      lines.push(`[${time}] ${author}: ${content}`);
    }
  }

  return { lines, count: allMessages.length };
}

export async function closeTicket(interaction) {
  const channel = interaction.channel;
  const config = getConfig(interaction.guild.id);
  const guild = interaction.guild;
  const member = interaction.member;

  const topicParts = channel.topic?.split(' | ') || [];
  const ticketOwnerId = channel.topic?.match(/Ticket for (\d+)/)?.[1];

  const isStaff = member.permissions.has('ManageChannels') || (config.tickets.supportRole && member.roles.cache.has(config.tickets.supportRole));
  const isOwner = interaction.user.id === ticketOwnerId;

  if (!isStaff && !isOwner) {
    return interaction.reply({ embeds: [errorEmbed('No Permission', 'Only staff or the ticket owner can close this ticket.')], ephemeral: true });
  }

  await interaction.reply({
    embeds: [{
      color: 0xE74C3C,
      title: 'Ticket Closing',
      description: 'Collecting transcript and closing in 5 seconds...',
      footer: { text: `Closed by ${interaction.user.username}` },
      timestamp: new Date().toISOString(),
    }],
  });

  if (config.tickets.logChannel) {
    const logCh = guild.channels.cache.get(config.tickets.logChannel);
    if (logCh) {
      const { lines, count } = await collectTranscript(channel);

      const ticketType = topicParts[1] || 'General';
      const opener = ticketOwnerId ? `<@${ticketOwnerId}>` : 'Unknown';

      const logEmbed = new EmbedBuilder()
        .setColor(0xE74C3C)
        .setTitle('Ticket Closed')
        .addFields(
          { name: 'Channel', value: channel.name, inline: true },
          { name: 'Type', value: ticketType.trim(), inline: true },
          { name: 'Opened By', value: opener, inline: true },
          { name: 'Closed By', value: `${interaction.user.username}`, inline: true },
          { name: 'Messages', value: `${count}`, inline: true },
        )
        .setTimestamp()
        .setFooter({ text: 'Ravage Guard — Ticket Log' });

      await logCh.send({ embeds: [logEmbed] }).catch(() => {});

      if (lines.length > 0) {
        const transcript = lines.join('\n');

        if (transcript.length <= 1900) {
          await logCh.send({
            embeds: [{
              color: 0x2F3136,
              title: `Transcript — ${channel.name}`,
              description: '```\n' + transcript + '\n```',
              footer: { text: `${count} message(s) recorded` },
            }],
          }).catch(() => {});
        } else {
          const chunks = [];
          let current = '';
          for (const line of lines) {
            if (current.length + line.length + 1 > 1800) {
              chunks.push(current);
              current = '';
            }
            current += (current ? '\n' : '') + line;
          }
          if (current) chunks.push(current);

          for (let i = 0; i < chunks.length; i++) {
            await logCh.send({
              embeds: [{
                color: 0x2F3136,
                title: i === 0 ? `Transcript — ${channel.name}` : null,
                description: '```\n' + chunks[i] + '\n```',
                footer: i === chunks.length - 1 ? { text: `${count} message(s) recorded | Page ${i + 1}/${chunks.length}` } : { text: `Page ${i + 1}/${chunks.length}` },
              }],
            }).catch(() => {});
          }
        }
      }
    }
  }

  setTimeout(() => channel.delete().catch(() => {}), 5000);
}

export async function claimTicket(interaction) {
  const config = getConfig(interaction.guild.id);
  const member = interaction.member;
  const isStaff = member.permissions.has('ManageChannels') || (config.tickets.supportRole && member.roles.cache.has(config.tickets.supportRole));

  if (!isStaff) {
    return interaction.reply({ embeds: [errorEmbed('No Permission', 'Only staff can claim tickets.')], ephemeral: true });
  }

  await interaction.reply({
    embeds: [successEmbed('Ticket Claimed', `This ticket has been claimed by ${interaction.user}.`)],
  });
}
