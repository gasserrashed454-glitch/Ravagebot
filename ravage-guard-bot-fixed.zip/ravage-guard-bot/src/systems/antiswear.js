import { getConfig, saveConfig } from '../config.js';
import { modLogEmbed } from '../utils/embeds.js';

const userViolations = new Map();

export async function handleAntiSwear(message, client) {
  if (!message.guild || message.author.bot) return;
  const config = getConfig(message.guild.id);
  if (!config.antiswear.enabled) return;

  const member = message.member;
  if (member.permissions.has('ManageMessages') || member.permissions.has('Administrator')) return;

  const content = message.content.toLowerCase().replace(/[^a-z0-9\s]/g, '');
  const words = config.antiswear.words || [];
  const found = words.find(w => content.includes(w.toLowerCase()));
  if (!found) return;

  try {
    await message.delete();
  } catch {}

  if (config.antiswear.warnDM) {
    try {
      await message.author.send({
        embeds: [{
          color: 0xE74C3C,
          title: '⚠️ Inappropriate Language Detected',
          description: `Your message in **${message.guild.name}** was removed for containing inappropriate language.\n\nPlease keep the chat clean and respectful.`,
          footer: { text: 'Ravage Guard • Auto Moderation' },
          timestamp: new Date().toISOString(),
        }],
      });
    } catch {}
  }

  const key = `${message.guild.id}-${message.author.id}`;
  const violations = (userViolations.get(key) || 0) + 1;
  userViolations.set(key, violations);

  setTimeout(() => {
    const current = userViolations.get(key) || 0;
    if (current > 0) userViolations.set(key, current - 1);
  }, 60000);

  if (config.antiswear.logChannel) {
    const logChannel = message.guild.channels.cache.get(config.antiswear.logChannel);
    if (logChannel) {
      const embed = modLogEmbed({
        action: 'ANTISWEAR',
        user: message.author,
        moderator: client.user,
        reason: `Used banned word: "${found}"`,
        extra: `Violations this minute: ${violations}`,
      });
      logChannel.send({ embeds: [embed] }).catch(() => {});
    }
  }

  if (violations >= 3) {
    try {
      const member = message.guild.members.cache.get(message.author.id);
      await member.timeout(5 * 60 * 1000, 'Repeated use of banned words (Auto-Mod)');
      userViolations.set(key, 0);
    } catch {}
  }
}

export function addSwearWord(guildId, word) {
  const config = getConfig(guildId);
  if (!config.antiswear.words.includes(word.toLowerCase())) {
    config.antiswear.words.push(word.toLowerCase());
    saveConfig(guildId, config);
  }
}

export function removeSwearWord(guildId, word) {
  const config = getConfig(guildId);
  config.antiswear.words = config.antiswear.words.filter(w => w !== word.toLowerCase());
  saveConfig(guildId, config);
}
