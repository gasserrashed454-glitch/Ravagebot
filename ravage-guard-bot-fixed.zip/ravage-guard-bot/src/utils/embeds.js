import { EmbedBuilder } from 'discord.js';

const BRAND_COLOR = 0x1ABC9C;
const SUCCESS_COLOR = 0x57F287;
const ERROR_COLOR = 0xED4245;
const WARNING_COLOR = 0xFEE75C;
const INFO_COLOR = 0x5865F2;

export function successEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(SUCCESS_COLOR)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'Ravage Guard' });
}

export function errorEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(ERROR_COLOR)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'Ravage Guard' });
}

export function warnEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(WARNING_COLOR)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'Ravage Guard' });
}

export function infoEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(INFO_COLOR)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'Ravage Guard' });
}

export function brandEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'Ravage Guard' });
}

function displayName(user) {
  if (!user) return 'Unknown';
  if (typeof user === 'string') return user;
  return user.username || user.tag || 'Unknown';
}

export function modLogEmbed({ action, user, moderator, reason, duration, extra }) {
  const colors = {
    BAN: ERROR_COLOR,
    UNBAN: SUCCESS_COLOR,
    KICK: 0xEB459E,
    MUTE: WARNING_COLOR,
    UNMUTE: SUCCESS_COLOR,
    WARN: WARNING_COLOR,
    DELETE: 0x99AAB5,
    ANTINUKE: ERROR_COLOR,
    ANTISWEAR: INFO_COLOR,
  };

  const labels = {
    BAN: 'Ban',
    UNBAN: 'Unban',
    KICK: 'Kick',
    MUTE: 'Mute',
    UNMUTE: 'Unmute',
    WARN: 'Warning',
    DELETE: 'Message Deleted',
    ANTINUKE: 'Anti-Nuke Triggered',
    ANTISWEAR: 'Anti-Swear Filter',
  };

  const embed = new EmbedBuilder()
    .setColor(colors[action] || BRAND_COLOR)
    .setTitle(labels[action] || action)
    .setTimestamp()
    .setFooter({ text: 'Moderation Log' });

  if (user) {
    const uid = user.id || user;
    embed.addFields({ name: 'User', value: `<@${uid}> — ${displayName(user)}`, inline: true });
  }
  if (moderator) {
    const mid = moderator.id || moderator;
    embed.addFields({ name: 'Moderator', value: `<@${mid}> — ${displayName(moderator)}`, inline: true });
  }
  if (reason) embed.addFields({ name: 'Reason', value: reason, inline: false });
  if (duration) embed.addFields({ name: 'Duration', value: duration, inline: true });
  if (extra) embed.addFields({ name: 'Info', value: extra, inline: false });

  return embed;
}

export function ticketEmbed(ticketNumber, opener) {
  return new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle(`Ticket #${ticketNumber}`)
    .setDescription(`Hey ${opener}, thanks for reaching out.\n\nDescribe your issue below and a staff member will be with you as soon as possible. To close this ticket, use the button below.`)
    .setFooter({ text: 'Ravage Guard — Support' });
}

export function ticketPanelEmbed() {
  return new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle('Support Tickets')
    .setDescription('Need help from the team? Click the button below to open a ticket.\nA staff member will get back to you as soon as possible.')
    .addFields(
      { name: 'Before opening', value: 'Check announcements and FAQ first — your question may already be answered.', inline: false },
    )
    .setFooter({ text: 'Ravage Guard — Support' });
}
